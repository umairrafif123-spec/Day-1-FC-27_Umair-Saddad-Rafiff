# Student Task Planner

Student Task Planner adalah aplikasi web sederhana untuk membantu mahasiswa tahun pertama mengatur tugas dan deadline.

## Fitur
- Menampilkan daftar tugas contoh.
- Menampilkan judul tugas, mata kuliah, tanggal deadline, dan status.
- Menandai tugas sebagai selesai atau belum selesai.
- Memfilter tugas berdasarkan Semua, Pending, dan Completed.
- Menampilkan ringkasan total tugas, tugas yang belum selesai, dan tugas yang sudah selesai.
- Tampilan responsif untuk desktop dan perangkat mobile.

## Teknologi
- HTML
- CSS
- JavaScript (Vanilla)

## Struktur File
```text
student-task-planner/
├── index.html
├── style.css
├── script.js
└── README.md
```

## Cara Menjalankan
1. Download atau clone repository ini.
2. Pastikan `index.html`, `style.css`, dan `script.js` berada dalam folder yang sama.
3. Buka file `index.html` menggunakan browser.
4. Klik tombol kotak di sebelah tugas untuk mengubah status.
5. Gunakan filter Semua, Pending, atau Completed untuk melihat daftar tugas sesuai status.

## Catatan
Daftar tugas pada versi ini menggunakan data contoh yang ditulis di `script.js`. Perubahan status berlaku selama halaman sedang dibuka dan akan kembali ke data awal saat halaman dimuat ulang.
